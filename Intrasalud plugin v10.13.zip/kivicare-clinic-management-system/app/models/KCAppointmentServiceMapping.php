<?php

namespace App\models;

use App\baseClasses\KCModel;


class KCAppointmentServiceMapping extends KCModel {
    public function __construct()
    {
        parent::__construct('appointment_service_mapping');
    }
}


