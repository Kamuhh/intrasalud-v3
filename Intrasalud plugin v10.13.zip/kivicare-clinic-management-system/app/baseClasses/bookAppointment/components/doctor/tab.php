<a class="tab-link" href="#doctor" data-iq-toggle="tab" data-iq-tab="prevent" id="doctor-tab">
    <span class="sidebar-heading-text"><?php echo esc_html__('Choose Your Doctor', 'kc-lang' ); ?></span>
    <p> <?php echo esc_html__('pick a specific Doctor to perform your service', 'kc-lang' ); ?> </p>
</a>