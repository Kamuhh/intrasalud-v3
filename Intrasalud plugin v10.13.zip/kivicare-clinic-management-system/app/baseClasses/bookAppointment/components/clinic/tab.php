<a class="tab-link" href="#clinic" data-iq-toggle="tab" data-iq-tab="prevent" id="clinic-tab">
    <span class="sidebar-heading-text"> <?php echo esc_html__('Choose a Clinic', 'kc-lang'); ?> </span>
    <p> <?php echo esc_html__('Please select a Clinic you want to visit', 'kc-lang'); ?> </p>
</a>