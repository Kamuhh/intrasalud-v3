<a class="tab-link" href="#date-time" data-iq-toggle="tab" data-iq-tab="prevent" id="date-time-tab">
    <span class="sidebar-heading-text"> <?php echo esc_html__('Select Date and Time', 'kc-lang' ); ?> </span>
    <p> <?php echo esc_html__('Select date to see a timeline of available slots', 'kc-lang' ); ?> </p>
</a>