<div id="app" data-base-path="<?php esc_html(KIVI_CARE_DIR); ?>">
</div>